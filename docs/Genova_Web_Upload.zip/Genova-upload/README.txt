GENOVA / CUSTAR - WEBSITE UPLOAD PACKAGE
=========================================

Two places on custar.ng:

  https://www.custar.ng/          -> the Genova landing page (one file: index.html)
  https://www.custar.ng/Genova/   -> the Genova website: plans, sign in / sign up,
                                     account, checkout, privacy, support and the
                                     admin dashboard (/Genova/admin/)

WHAT IS IN THIS ZIP
-------------------
Genova-upload/
  README.txt                    this file (do NOT upload)
  public_html/                  EVERYTHING INSIDE THIS FOLDER GOES TO THE SITE ROOT
    index.html                  landing page  -> www.custar.ng/
    robots.txt                  search-engine rules for the whole site
    .htaccess                   forces https:// and adds basic security headers
    Genova/                     the Genova website -> www.custar.ng/Genova/
      index.html, 404.html      home page and "page not found" page
      account/ checkout/ forgot-password/ login/ plans/ privacy/ signup/ support/
                                one folder per page (each holds an index.html)
      admin/                    the admin dashboard -> www.custar.ng/Genova/admin/
      _next/                    the site's scripts and styles (must be uploaded)
      img/                      pictures
      landing.js, catalog.json  landing-page behaviour used by the home page
      config.js                 connects the site to Supabase (see "config.js")
      .htaccess                 headers and caching for /Genova (and admin/.htaccess)

HOW TO UPLOAD (cPanel / File Manager or FTP)
--------------------------------------------
1. Unzip the file on your computer.
2. Log in to the custar.ng hosting (cPanel > File Manager, or an FTP program).
3. Open the folder that serves www.custar.ng. On most cPanel hosts this is
   "public_html" (for the main domain). If your host calls it something else
   (www, htdocs, httpdocs), use that.
4. Upload the CONTENTS of the zip's public_html folder into that folder, so that
   you end up with:

       public_html/index.html            <- landing page
       public_html/robots.txt
       public_html/.htaccess
       public_html/Genova/index.html     <- Genova website
       public_html/Genova/admin/index.html
       public_html/Genova/_next/...
       public_html/Genova/img/...
       public_html/Genova/config.js
       ... and the other page folders

   Tip: in File Manager upload the whole zip into public_html and use "Extract",
   then move/flatten if it created an extra folder. The landing page "index.html"
   must sit directly in public_html, and the "Genova" folder directly in
   public_html - not inside another folder.
5. Hidden files: .htaccess files start with a dot. In cPanel File Manager click
   Settings > "Show Hidden Files (dotfiles)" so you can see and upload them.
   If your host is not Apache (e.g. Nginx-only), the .htaccess files are simply
   ignored and the site still works; ask the host to force https:// instead.
6. If custar.ng already has a WordPress or other site at the root, keep its files
   and replace/rename only its index file with this index.html (or point the
   landing page to a different page). Do not delete other things on the host
   without checking first.
7. Open these links to check:
     https://www.custar.ng/                    the landing page
     https://www.custar.ng/Genova/             the Genova website home
     https://www.custar.ng/Genova/plans/       plans
     https://www.custar.ng/Genova/login/       sign in
     https://www.custar.ng/Genova/admin/       admin dashboard sign-in
   If a page looks unstyled, the "_next" folder was not uploaded - upload it again.

UPDATING LATER
--------------
Upload a new copy over the old one and overwrite. Always upload the whole Genova
folder including _next (file names inside _next change with every update, so old
ones can be deleted after the new ones are in place).

config.js (CONNECTS THE SITE TO THE DATABASE)
---------------------------------------------
Genova/config.js holds the Supabase project address and the public "anon" key for
the GenovaStorybook project. It is meant to be public. Never put the Paystack
secret key or the Supabase service-role key in it.

THINGS TO SET UP ONCE (not part of the upload)
----------------------------------------------
These are dashboard settings, done by whoever manages Supabase and Paystack:

A. Supabase > Edge Functions > Secrets
     WEB_URL = https://www.custar.ng/Genova
   (include /Genova; no slash at the end). It is used for the payment return
   link and email links.
   IMPORTANT: the website's own code allows for the /Genova folder, but these
   functions must be updated (redeployed) first for the "Contact support", admin
   "Email" and admin password-help buttons to work from www.custar.ng:
     support-request, admin-user-support, send-email, send-reminders
   (paystack-checkout and paystack-manage are already updated). The updated
   code is in the repository (supabase/functions). Until they are redeployed,
   either leave WEB_URL unset for them or ask the developer to deploy them.
B. Supabase > Authentication > URL Configuration
     Site URL      = https://www.custar.ng/Genova
     Redirect URLs = https://www.custar.ng/Genova/**
C. Paystack: the webhook URL stays the Supabase function address (not custar.ng),
   and the two plans must be ₦3,000 monthly and ₦7,500 quarterly.
D. The app build variable EXPO_PUBLIC_WEB_URL = https://www.custar.ng/Genova
   (used by the app's "Change plan" link).
E. Landing page buttons: replace the placeholder Google Play and App Store links
   once the apps are published (they are in index.html; search for "Download for").

NOTES
-----
- The landing page links to the Genova pages with full addresses
  (https://www.custar.ng/Genova/login/, /signup/, /plans/, /privacy/, /support/).
- The admin dashboard (/Genova/admin/) is hidden from search engines.
- To rebuild from the source: see docs/HANDOFF.md ("Hosting at /Genova").
