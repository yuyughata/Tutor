GENOVA / CUSTAR - WEBSITE UPLOAD PACKAGE
=========================================

Two places on custar.ng:

  https://www.custar.ng/          -> the Genova landing page (one file: index.html)
  https://www.custar.ng/Genova/   -> the Genova website: plans, sign in / sign up,
                                     account, checkout, privacy, support and the
                                     admin dashboard (/Genova/admin/)

WHAT IS IN THIS ZIP
-------------------
Genova-upload/
  README.txt                    this file (do NOT upload)
  public_html/                  EVERYTHING INSIDE THIS FOLDER GOES TO THE SITE ROOT
    index.html                  landing page  -> www.custar.ng/
    robots.txt                  search-engine rules for the whole site
    .htaccess                   forces https:// and adds basic security headers
    Genova/                     the Genova website -> www.custar.ng/Genova/
      index.html, 404.html      home page and "page not found" page
      account/ checkout/ forgot-password/ login/ plans/ privacy/ signup/ support/
                                one folder per page (each holds an index.html)
      admin/                    the admin dashboard -> www.custar.ng/Genova/admin/
      _next/                    the site's scripts and styles (must be uploaded)
      img/                      pictures
      landing.js, catalog.json  landing-page behaviour used by the home page
      config.js                 connects the site to Supabase (see "config.js")
      .htaccess                 headers and caching for /Genova (and admin/.htaccess)

HOW TO UPLOAD (cPanel / File Manager or FTP)
--------------------------------------------
1. Unzip the file on your computer.
2. Log in to the custar.ng hosting (cPanel > File Manager, or an FTP program).
3. Open the folder that serves www.custar.ng. On most cPanel hosts this is
   "public_html" (for the main domain). If your host calls it something else
   (www, htdocs, httpdocs), use that.
4. Upload the CONTENTS of the zip's public_html folder into that folder, so that
   you end up with:

       public_html/index.html            <- landing page
       public_html/robots.txt
       public_html/.htaccess
       public_html/Genova/index.html     <- Genova website
       public_html/Genova/admin/index.html
       public_html/Genova/_next/...
       public_html/Genova/img/...
       public_html/Genova/config.js
       ... and the other page folders

   Tip: in File Manager upload the whole zip into public_html and use "Extract",
   then move/flatten if it created an extra folder. The landing page "index.html"
   must sit directly in public_html, and the "Genova" folder directly in
   public_html - not inside another folder.
5. Hidden files: .htaccess files start with a dot. In cPanel File Manager click
   Settings > "Show Hidden Files (dotfiles)" so you can see and upload them.
   If your host is not Apache (e.g. Nginx-only), the .htaccess files are simply
   ignored and the site still works; ask the host to force https:// instead.
6. If custar.ng already has a WordPress or other site at the root, keep its files
   and replace/rename only its index file with this index.html (or point the
   landing page to a different page). Do not delete other things on the host
   without checking first.
7. Open these links to check:
     https://www.custar.ng/                    the landing page
     https://www.custar.ng/Genova/             the Genova website home
     https://www.custar.ng/Genova/plans/       plans
     https://www.custar.ng/Genova/login/       sign in
     https://www.custar.ng/Genova/admin/       admin dashboard sign-in
   If a page looks unstyled, the "_next" folder was not uploaded - upload it again.

UPDATING LATER (for example after a change such as Show/Hide password)
---------------------------------------------------------------------
Any change to the website or the admin dashboard only appears after the new files
are uploaded. Each time:
1. Get the new zip (or have the developer rebuild it: see docs/HANDOFF.md).
2. Upload the new public_html/Genova folder over the old one and overwrite.
   Always upload the WHOLE Genova folder including _next: the file names inside
   _next change with every update, and the pages point to the new names.
3. Upload index.html (the landing page) to the site root only if the landing page
   changed.
4. Delete old files in Genova/_next once the new ones are in place (optional).
5. Hard-refresh the browser (Ctrl+F5, or Cmd+Shift+R) or open a private window,
   because browsers keep old copies of pages and scripts.
Changes to the mobile app need a new app build; changes to emails and the
database are made separately and do not need an upload.

config.js (CONNECTS THE SITE TO THE DATABASE)
---------------------------------------------
Genova/config.js holds the Supabase project address and the public "anon" key for
the GenovaStorybook project. It is meant to be public. Never put the Paystack
secret key or the Supabase service-role key in it.

THINGS TO SET UP ONCE (not part of the upload)
----------------------------------------------
These are dashboard settings, done by whoever manages Supabase and Paystack:

A. Supabase > Edge Functions > Secrets
     WEB_URL = https://www.custar.ng/Genova
   (include /Genova; no slash at the end). It is used for the payment return
   link and email links. The functions support-request, admin-user-support and
   send-email already run the updated code; send-reminders and paystack-webhook
   still need to be redeployed by the developer for the new email logo.
B. Supabase > Authentication > URL Configuration
     Site URL      = https://www.custar.ng/Genova
     Redirect URLs = https://www.custar.ng/Genova/**
C. Paystack: the webhook URL stays the Supabase function address (not custar.ng),
   and the two plans must be ₦3,000 monthly and ₦7,500 quarterly.
D. The app build variable EXPO_PUBLIC_WEB_URL = https://www.custar.ng/Genova
   (optional: the app already defaults to this address).
E. Landing page buttons: "Download for Android" opens the APK on Google Drive; swap it for the Google Play page
   once the app is published. "Download for iOS" is still a placeholder App Store address. Both are in index.html
   (search for "Download for").

NOTES
-----
- The landing page links to the Genova pages with full addresses
  (https://www.custar.ng/Genova/login/, /signup/, /plans/, /privacy/, /support/).
- The admin dashboard (/Genova/admin/) is hidden from search engines.
- To rebuild from the source: see docs/HANDOFF.md ("Hosting at /Genova").
